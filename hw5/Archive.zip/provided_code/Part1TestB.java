public class Part1TestB{
    public static void main(String[] args) {
        reverse();
    }

    public static void reverse(){
        Part1.z();
        Part1.y();
        Part1.x();
        Part1.w();
        Part1.v();
        Part1.u();
        Part1.t();
        Part1.s();
        Part1.r();
        Part1.q();
        Part1.p();
        Part1.o();
        Part1.n();
        Part1.m();
        Part1.l();
        Part1.k();
        Part1.j();
        Part1.i();
        Part1.h();
        Part1.g();
        Part1.f();
        Part1.e();
        Part1.d();
        Part1.c();
        Part1.b();
        Part1.a();
    }
}