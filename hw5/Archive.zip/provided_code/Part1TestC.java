public class Part1TestC{
    public static void main(String[] args) {
        rotate();
    }

    public static void rotate(){
        Part1.a();
        Part1.c();
        Part1.e();
        Part1.g();
        Part1.i();
        Part1.k();
        Part1.m();
        Part1.o();
        Part1.q();
        Part1.s();
        Part1.w();
        Part1.y();
        Part1.z();
        Part1.x();
        Part1.v();
        Part1.t();
        Part1.r();
        Part1.p();
        Part1.n();
        Part1.l();
        Part1.j();
        Part1.h();
        Part1.f();
        Part1.d();
        Part1.b();
    }
}