public class Part1TestA{
    public static void main(String[] args) {
        inOrder();
    }

    public static void inOrder(){
        Part1.a();
        Part1.b();
        Part1.c();
        Part1.d();
        Part1.e();
        Part1.f();
        Part1.g();
        Part1.h();
        Part1.i();
        Part1.j();
        Part1.k();
        Part1.l();
        Part1.m();
        Part1.n();
        Part1.o();
        Part1.p();
        Part1.q();
        Part1.r();
        Part1.s();
        Part1.t();
        Part1.u();
        Part1.v();
        Part1.w();
        Part1.x();
        Part1.y();
        Part1.z();
    }

}