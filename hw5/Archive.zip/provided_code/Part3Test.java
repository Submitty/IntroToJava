public class Part3Test{
    public static void main(String[] args) {
        
        System.out.println(Part3.factorial(10));
        System.out.println(Part3.fib(25));
        System.out.println(Part3.fibFast(30));

    }
}